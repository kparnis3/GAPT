using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SharkBite : MonoBehaviour
{
   public Animator anim;
   private AudioSource _audioSource;
    // Update is called once per frame
   void Start()
   {
     _audioSource=GetComponent<AudioSource>();
   } 
   void OnTriggerEnter2D(Collider2D other)
    {   
       if(other.gameObject.CompareTag("BigFish") || other.gameObject.CompareTag("MedFish") || other.gameObject.CompareTag("LittleFish"))
        {
          anim.SetTrigger("Sharkbite");
          _audioSource.Play();
        }
    }
}