using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;

public class TestAgent : Agent
{
    /*public override void OnEpisodeBegin()
    {

    }

    public override void CollectObservations(VectorSensor sensor)
    {
        sensor.AddObservation(transform.position);
    }
    
    public override void OnActionReceived(ActionBuffers actions)
    {
        float moveY = actions.ContinousActions[0];

        float moveSpeed = 1f;
        transform.position += new Vector3(0, MoveY, 0) * Time.deltaTime * moveSpeed;
    }

  
    private void OnTriggerEnter2D(Collider2D other)
    {
       if(other.gameObject.CompareTag("BigFish"))
        {
            AddReward(300f);
        }
        else if(other.gameObject.CompareTag("MedFish"))
        {
            AddReward(200f);
        }
        else if(other.gameObject.CompareTag("LittleFish"))
        {
            AddReward(100f);
        }
    }
    */
}
