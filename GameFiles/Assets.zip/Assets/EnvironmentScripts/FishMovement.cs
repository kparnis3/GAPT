using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishMovement : MonoBehaviour
{
   public float speed;

    void Update()
    {
        moveLeft();
    }

    void moveLeft()
    {
        transform.Translate(Vector3.left * speed * Time.deltaTime);
    }
}

