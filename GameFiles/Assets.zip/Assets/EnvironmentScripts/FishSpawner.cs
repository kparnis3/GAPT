using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FishSpawner : MonoBehaviour
{
    public GameObject bigFish;
    public Transform fishSpawnPoint;
    public float minTime;
    public float maxTime;
    public float timer;

    // Update is called once per frame
    void Update()
    {
        if(timer <= 0)
        {
            SpawnFish();
        }
        timer -= Time.deltaTime;
        
    }

    void SpawnFish()
    {

        var position = new Vector3(fishSpawnPoint.position.x, Random.Range(-6f, 5.8f), 0f);
        Instantiate(bigFish, position, Quaternion.identity);

        timer = Random.Range(minTime, maxTime);
    }



}
