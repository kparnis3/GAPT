using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SharkKeepScore : MonoBehaviour
{
   public GameData GameData;
    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.CompareTag("BigFish"))
        {
            GameData.UpdateBigScore();
        }
        else if(other.gameObject.CompareTag("MedFish"))
        {
            GameData.UpdateMedScore();
        }
        else if(other.gameObject.CompareTag("LittleFish"))
        {
            GameData.UpdateLittleScore();
        }
    }
}
