using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class buttonK : MonoBehaviour
{
    // Start is called before the first frame update
    public Button buttonFish;
    public Button buttonCan;
    private ColorBlock pressedColor;
    private ColorBlock unpressedColor;
    public GameObject smallFish;
    public GameObject medFish;
    public GameObject bigFish;
    public GameObject can;

    public GameObject Trash2;
    public GameObject Trash3;
    bool isFish = true;
    public void OnCanClick()
    {
        var colorOne = buttonCan.colors;
        colorOne.normalColor = Color.green;
        var colorTwo = buttonFish.colors;
        colorTwo.normalColor = Color.white;
        
        isFish = false;
        Debug.Log("Can clicked!");
        
        buttonCan.colors = colorOne;
        buttonFish.colors = colorTwo;
    }
  
    // Update is called once per frame
    public void OnFishClick()
    {

        var colorOne = buttonFish.colors;
        colorOne.normalColor = Color.green;
        var colorTwo = buttonCan.colors;
        colorTwo.normalColor = Color.white;

        isFish = true;
        Debug.Log("Fish clicked!");
        

        buttonFish.colors = colorOne;
        buttonCan.colors = colorTwo;
    }

    public void Update()
    {
        if (Input.GetMouseButtonDown(1))
            {
                if(isFish)
                {
                    Vector3 mousePos = Input.mousePosition;
                    mousePos.z = 2.0f;       // we want 2m away from the camera position
                    Vector3 objectPos = Camera.main.ScreenToWorldPoint(mousePos);
                    var val = Random.Range(0, 3);
                    Debug.Log(val);
                    if(val==0)
                    {
                        Instantiate(bigFish, objectPos, Quaternion.identity);
                    }
                    else if(val==1)
                    {
                        Instantiate(medFish, objectPos, Quaternion.identity);
                    }
                    else
                    {
                        Instantiate(smallFish, objectPos, Quaternion.identity);
                    }
                    
                }
                else
                {
                   
                    Vector3 mousePos = Input.mousePosition;
                    mousePos.z = 2.0f;       // we want 2m away from the camera position
                    Vector3 objectPos = Camera.main.ScreenToWorldPoint(mousePos);
                    var val = Random.Range(0, 3);
                     if(val==0)
                    {
                        Instantiate(can, objectPos, Quaternion.identity);
                    }
                    else if(val==1)
                    {
                        Instantiate(Trash2, objectPos, Quaternion.identity);
                    }
                    else
                    {
                        Instantiate(Trash3, objectPos, Quaternion.identity);
                    } 
                }
            }
    }
    
}
