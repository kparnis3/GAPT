using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnClick : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject myObject;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            myObject.GetComponent<ResetScene>().Resetall();
        }
    }
}
