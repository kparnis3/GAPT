using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class GameData : MonoBehaviour
{   
    // Start is called before the first frame update
    public static GameData singleton;
    public int score;
    public int highscore;
    public Text highScoreText;
    public Text ScoreText;
    void Start()
    {
        score = 0;
        highscore = 0;
    }

    public void Awake()
    {
        SetScore();
        sethighScore();
        GameObject[] gd = GameObject.FindGameObjectsWithTag("GameData");

        if(gd.Length > 1)
        {
            Destroy(this.gameObject);
        }

        DontDestroyOnLoad(this.gameObject);
        singleton = this;
    }

    public void UpdateBigScore()
    {
        score += 300;
        SetScore();
    }

    public void UpdateMedScore()
    {
        score += 200;
        SetScore();
    }

    public void UpdateLittleScore()
    {
        score += 100;
        SetScore();
    }

    public void ResetScore()
    {
        
        if(score > highscore)
        {
            highscore = score;
            sethighScore();
        }
        score = 0;
        SetScore();
    }

    public void SetScore()
    {
        ScoreText.text = "Score: " +score.ToString();
    }

    public void sethighScore()
    {
        highScoreText.text = "High Score: " +highscore.ToString();
    }
}
