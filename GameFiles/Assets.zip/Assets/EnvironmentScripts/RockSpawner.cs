using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RockSpawner : MonoBehaviour
{
    public GameObject Rock;
    public GameObject Trash2;
    public GameObject Trash3;
    public Transform SpawnPoint;
    public float minTime;
    public float maxTime;
    public float timer;

    // Update is called once per frame
    void Update()
    {
        if(timer <= 0)
        {
            SpawnRock();
        }
        timer -= Time.deltaTime;

    }

    void SpawnRock()
    {

        var position = new Vector3(SpawnPoint.position.x, Random.Range(-6f, 5.8f), 0f);
        var val = Random.Range(0, 3);
        if(val==0)
        {
            Instantiate(Rock, position, Quaternion.identity);
        }
       else if(val==1)
        {
            Instantiate(Trash2, position, Quaternion.identity);
        }
        else
        {
            Instantiate(Trash3, position, Quaternion.identity);
        }

        timer = Random.Range(minTime, maxTime);
    }
}
