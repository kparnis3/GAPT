using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pauseBehaviour : MonoBehaviour
{
    [SerializeField] private GameObject pauseUI;
    [SerializeField] private bool isPaused;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            isPaused = !isPaused;
        }

        if (isPaused)
        {
            pauseGame();
        }
        else
        {
            resumeGame();
        }
    }

    public void resumeGame()
    {
        pauseUI.SetActive(false);
        Time.timeScale = 1f; //un-freezes game
    }

    public void pauseGame()
    {
        pauseUI.SetActive(true);
        Time.timeScale = 0f; //freezes game
    }
}
