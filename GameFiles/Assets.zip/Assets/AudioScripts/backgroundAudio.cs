using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class backgroundAudio : MonoBehaviour
{
    [SerializeField] string audioVolumeVar = "backgroundAudioVolume";
    [SerializeField] AudioMixer backgroundAudioMixer;
    [SerializeField] Slider backgroundSlider;

    public GameObject music;

    //private float musicFloat;
    [SerializeField] float multiplierVar = 20f;

    public void Awake()
    {
        backgroundSlider.onValueChanged.AddListener(setMusicVolume);
        DontDestroyOnLoad(music);
    }

    private void OnDisable()
    {
        PlayerPrefs.SetFloat(audioVolumeVar, backgroundSlider.value);
    }

    public void setMusicVolume(float musicValue)
    {
        //Set Music Volume from Slider
        backgroundAudioMixer.SetFloat(audioVolumeVar, Mathf.Log10(musicValue) * multiplierVar);
    }

    void Start()
    {
        //Saving the user's preferences 
        backgroundSlider.value = PlayerPrefs.GetFloat(audioVolumeVar, backgroundSlider.value);
    }
}
