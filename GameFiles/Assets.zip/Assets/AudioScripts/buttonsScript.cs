using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class buttonsScript : MonoBehaviour
{
    /*
     Main Menu: Start, How To, Settings, Quit
     How To: Back
     Settings: Back
     Pause: Resume, How To, Settings, Back To Main Menu
     */

    public void howTo()
    {
        SceneManager.LoadScene("howTo");
    }
    public void settings()
    {
        SceneManager.LoadScene("settings");
    }

    public void startGame()
    {
        SceneManager.LoadScene("Main");
    }

    public void backToMainMenu()
    {
        SceneManager.LoadScene("mainMenu");
    }

    public void quitGame()
    {
        Application.Quit();
        Debug.Log("Quitting Game!");
    }
}
