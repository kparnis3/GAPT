using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;

public class MlPlayer : Agent
{   
    public GameObject MyReset;
    public GameObject MyShark;

    public override void OnActionReceived(ActionBuffers actions)
    {
        AddReward(+0.001f); //Just staying Alive

        float Move = 0f;

        switch (actions.DiscreteActions[0])
        {
          case 0: Move = 0f; break; 
          case 1: Move = +1f; break;
          case 2: Move = -1f; break;
        }

       if(Move!=0f)
       {
           AddReward(-0.25f);
       }

        MyShark.GetComponent<Movement>().applyForce(Move);
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        int upDown = 0;
        if(Input.GetKey(KeyCode.UpArrow)) upDown = 1;
        if(Input.GetKey(KeyCode.DownArrow)) upDown = 2;

        ActionSegment<int> discreteActions = actionsOut.DiscreteActions;
        discreteActions[0] = upDown;
    }

    public override void OnEpisodeBegin()
    {    
       MyReset.GetComponent<ResetScene>().Resetall();  
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.CompareTag("BigFish"))
        {
            AddReward(+12f);
        }
        else if(other.gameObject.CompareTag("MedFish"))
        {
            AddReward(+8f);
        }
        else if(other.gameObject.CompareTag("LittleFish"))
        {
            AddReward(+4f);
        }
        else if(other.gameObject.CompareTag("Rock"))
        {
            AddReward(-1000.0f);
            EndEpisode();
            Debug.Log("Called!");
        }
        else if(other.gameObject.CompareTag("wall"))
        {
            AddReward(-2f);
            Debug.Log("Hitting wall");
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if(other.gameObject.CompareTag("wall"))
        {
            AddReward(-2f);
            Debug.Log("Staying at wall");
        }
    }


  


}
