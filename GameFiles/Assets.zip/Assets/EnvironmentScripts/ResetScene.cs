using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class ResetScene : MonoBehaviour
{
    public GameObject myGameManager;
    public GameObject myShark;

   
    // Start is called before the first frame update
    public void Resetall()
    {
        GameObject[] Bigfishes = GameObject.FindGameObjectsWithTag("BigFish");
        GameObject[] Medfishes = GameObject.FindGameObjectsWithTag("MedFish");
        GameObject[] Littlefishes = GameObject.FindGameObjectsWithTag("LittleFish");
        GameObject[] Rocks = GameObject.FindGameObjectsWithTag("Rock");

        foreach(GameObject fish in Bigfishes)
        {
            GameObject.Destroy(fish);
        }

        foreach(GameObject fish in Medfishes)
        {
            GameObject.Destroy(fish);
        }

        foreach(GameObject fish in Littlefishes)
        {
            GameObject.Destroy(fish);
        }

        foreach(GameObject Rock in Rocks)
        {
            GameObject.Destroy(Rock);
        }
        
        
         myGameManager.GetComponent<GameData>().ResetScore();
         myShark.transform.position = new Vector3(-11, 0, 0);
         
    }
}
