using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Movement : MonoBehaviour
{
    Rigidbody2D body;
    float vertical;
    public float runSpeed = 6.0f;

    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody2D>(); 
    }

    // Update is called once per frame
    /*void Update()
    {
        vertical = Input.GetAxisRaw("Vertical");
    }*/

    public void applyForce(float movement)
    {
        body.velocity = new Vector2(0, movement * runSpeed);  
    }

    /*private void FixedUpdate()
    {
        body.velocity = new Vector2(0, vertical * runSpeed);   
    }*/
}
