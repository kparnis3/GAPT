using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class sfxAudio : MonoBehaviour
{
    [SerializeField] string sfxVolumeVar = "sfxAudioVolume";
    [SerializeField] AudioMixer sfxAudioMixer;
    [SerializeField] Slider sfxSlider;

    public GameObject sfx;

    //private float sfxFloat;
    [SerializeField] float multiplierVar = 20f;

    public void Awake()
    {
        sfxSlider.onValueChanged.AddListener(setSFXVolume);
        //DontDestroyOnLoad(sfx); //Possibly not necessary
    }

    private void OnDisable()
    {
        PlayerPrefs.SetFloat(sfxVolumeVar, sfxSlider.value);
    }

    public void setSFXVolume(float sfxValue)
    {
        //Set SFX Volume from Slider
        sfxAudioMixer.SetFloat(sfxVolumeVar, Mathf.Log10(sfxValue) * multiplierVar);
    }

    // Start is called before the first frame update
    void Start()
    {
        //Saving the user's preferences 
        sfxSlider.value = PlayerPrefs.GetFloat(sfxVolumeVar, sfxSlider.value);
    }
}
